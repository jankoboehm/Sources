STDIN   1> int i = 1;
STDIN   2> i;
1
